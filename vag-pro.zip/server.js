const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();

app.use(express.static('public'));
app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/vag');

const Product = mongoose.model('Product', { name: String });

app.post('/add-product', async (req, res) => {
  const product = new Product({ name: req.body.name });
  await product.save();
  res.send("OK");
});

app.get('/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.listen(3000, () => console.log("Server çalışıyor"));
